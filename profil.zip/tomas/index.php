<?php include('./parts/header.php')?>
<?php include('getallusers.php')?>
<main class="container">

  
      <h1 class="m-4 text.uppercase">Zoznam uživateľov</h1>
      <ul CLASS="list-group m-4">
        <li class="list-group-item list-group-item-action active d-flex row">
          <span class="col-1"> Id.</span>
          <span class="col-2"> Avatar</span>
          <span class="col-2"> Username</span>
          <span class="col-2"> Email</span>
          <span class="col-3"> Registred</span>
          <span class="col-2 text-center"> Akcie</span>
        </li>
        <?php foreach ($users as $user) : ?>
          <a href="index.php" class="text-decoration-none">
            <li class="lidt-group.item list-group-item-action active d-flex row align-items-center">
                </span class="text-danger col-1"> <?php echo $user["id"] ?></span>
                <div class="col-2">
                  <img src="./images"<?php echo $user["avatar"] ?>" alt="<?php echo $user["username"] ?>"
            </li>
            <?php print_r($user) ?>
        <?php endforeach; ?>
    </ul>

        </main>
        <?php include('./parts/footer.php') ?>


<main class="container">

    </main>
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://besthqwallpapers.com/Uploads/1-9-2017/19717/thumb2-volkswagen-golf-tuning-mk2-stance-german-cars.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://i0.wp.com/www.startstop.sk/wp-content/uploads/2019/03/bmw-e30-m3-redux-02.jpg?fit=1000%2C593&ssl=1" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://www.mercedes-benz.com/en/classic/history/h-number-plate-2020/_jcr_content/image/MQ6-12-image-20191205120027/01-mercedes-benz-classic-h-number-plate-2020-2560x1440.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://www.carscoops.com/wp-content/uploads/2022/01/Nissan-Silvia-240-SX-r1-1024x555.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://cdn.elferspot.com/wp-content/uploads/2020/11/RWB-Porsche-for-sale-1024x682.jpg" class="d-block w-100" alt="...">
    </div>
</div>
<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<?php include('./parts/footer.php')?>
