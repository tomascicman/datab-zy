


<?php
require('db.php');

if (isset($_REQUEST['username'])){

	$username = stripslashes($_REQUEST['username']);
	$surname = stripslashes($_REQUEST['surname']);        
	$username = mysqli_real_escape_string($con,$username); 
	$surname = mysqli_real_escape_string($con,$surname); 
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	$confirm_password = $_POST['confirm_password'];
	$trn_date = date("Y-m-d H:i:s");
        if ($password==$confirm_password && strlen($password) >= 6){
        $query = "INSERT into `users` (username, surname, password, email, trn_date)
VALUES ('$username', '$surname', '".md5($password)."', '$email', '$trn_date')";
        
        $result = mysqli_query($con,$query,);
    }
    else {
        echo"Nebol si zaregistrovaný, skús to znova! <a href='register.php'>Skúsiť znova</a>";
    }

        if($result){
            header("location: login.php");
        }    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login & Register by Tomáš Čičman">
    <title>Register</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>
<?php include("./parts/header.php")?>
    <div class="container">
        <h2>Registrácia</h2>
        <form action="" method="post">
            <div class="table">
                <label>Meno</label><br>
                <input type="text" name="username" placeholder="Tomas">
            </div>
            <div class="table">
                <label>Priezvisko</label><br>
                <input type="text" name="surname" placeholder="Cicman">
            </div>
            <div class="table">
                <label>Email</label><br>
                <input type="email" name="email" placeholder="tomas@cicman.sk">
            </div>
            <div class="table">
                <label>Heslo</label><br>
                <input type="password" name="password" placeholder="****">
            </div>
            <div class="table">
                <label>Znova heslo</label><br>
                <input type="password" name="confirm_password" placeholder="****">
            </div>
            <div class="table">
                <button type="submit" class="btn" value="Submit">Odoslať</button>
            </div>
            <div class="">
                <p>Máš už účet? <a class="reg" href="./login.php">Prihlásiť sa!</a>.</p>
            </div>
        </form>
    </div>

</body>

</html>