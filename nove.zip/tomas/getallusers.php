<?php include('./parts/header.php')?>
<?php include('getallusers.php')?>


<main class="container">
<ul CLASS="list-group">
        <li class="lidt-group.item">
           </span class="text-danger"> <strong> ID. USERNAME </strong></span>
        </li>
            <?php foreach ($users as $user) : ?>
          <li class="lidt-group.item">
            <a href="#" class="text-danger"> <?php echo $user["id"] . " ". $users["username"] ?></a>
          </li>
        <?php endforeach; ?>
    </ul>
    