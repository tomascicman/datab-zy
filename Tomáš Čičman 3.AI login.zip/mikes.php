<?php
require('./db.php');
session_start();
if (isset($_POST['username'])){
	$username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
        $query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
            echo"Bol si prihlásený/á";
        }else{
            echo"Nebol si prihlásený, skús to znova! <a href='index.php'>Skúsuť znova</a>";
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login & Register by Tomáš Čičman">
    <title>Login</title>

    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="container">
        <h1>Login • Tomáš Čičman</h1>
        <h4>Starostlivo si prosím vyplnte údaje.</h4>

        <div class="form">
            <form action="" method="post" name="login">
                <div class="table">
                    <label>Meno</label>
                    <input type="name" name="username" placeholder="username">
                </div>
                <div class="table">
                    <label>Heslo</label>
                    <input type="password" name="password" placeholder="******">
                </div>
                <button type="submit" class="" name="submit" value="Login">Prihlásiť</button>
            </form>
            <h4>Ešte nie si registrovaný/á?</h4><a class="reg" href="./register.php">registrovať sa!</a>
        </div>
    </div>

</body>
</html>