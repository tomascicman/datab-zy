<?php
$user = $_POST["username"];
$pass = $_POST["password"];
$hashed_password = password_hash($_POST["password"], PASSWORD_BCRYPT);

if(empty($user) || empty($pass)){
    header("Location: /tomas/login.php?message=Niečo si nezadal");
}

require_once("./db.php");

$sql = "SELECT * FROM users WHERE username=$user and $password=$hashed_password";
echo $sql;
$result = $conn->query($sql);

if($result->num_rows ==1){
    session_start();
    $_SESSION["username"] = $user;

    header("Location: /tomas/login.php?message=USPESNE PRIHLASENIE");
}
else{
    header("Location: /tomas/login.php?message=Zadal si zlé meno alebo heslo");
}
?>