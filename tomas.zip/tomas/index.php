<?php include('./parts/header.php')?>
<?php
    $error = isset($_GET["message"]) ? $_GET["message"] :"";
?>


<main class="container">
    <
    </main>

<?php include('./parts/footer.php')?>
