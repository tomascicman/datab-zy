/*1. SELECT Vyberie kapitanov ktorý majú viac ako šé rokov*/
SELECT meno FROM captain WHERE vek > 30;
/*2. SELECT vypise a zoradi názov štadionov podla abecedy*/
SELECT nazov FROM stadium ORDER BY nazov;
/*3. SELECT vypise všetky info. o kluboch ktore maju menej zapasov ako 15*/
SELECT * FROM teams WHERE pocet_zapasov < 15 ORDER BY nazov;
/*4. SELECT vypise skratky tímov ktoré maju 15 zápasov*/
SELECT skratka FROM teams WHERE pocet_zapasov = 15;
/*5. SELECT vypise info o treneroch ak maju viac rokov ako 45 a menej ako 50 alebo ak je z Anglicka*/
SELECT * FROM coach WHERE vek<50 AND vek>45 OR narodnost = "Anglicko";
/*6. SELECT vypise všetkych rozhodcov okrem tych čo majú 2 červené karty*/
SELECT * FROM referee WHERE pocet_cervenych_kariet != 2;
/*7. SELECT vypise z tabulky všetkých obrancov*/
SELECT *FROM captain WHERE pozicia LIKE 'obranc%';
/*8. SELECT spočíta kolko hráčov hrá na danej pozicií*/
SELECT pozicia, COUNT(*) AS pocet_pozicii FROM captain GROUP BY pozicia;
/*9. SELECT spocita kolko trenerov ma dany vek ale vek musi mat menej ako 55*/
SELECT vek, COUNT(*) AS pocet_trenerov FROM coach GROUP BY vek HAVING vek<55;
/*10. SELECT  zoskupi rozhodcov podla toho kolko dali červených kariet*/
SELECT pocet_cervenych_kariet, COUNT(*) AS pocet_rozhodcov FROM  referee GROUP BY pocet_cervenych_kariet ORDER BY pocet_rozhodcov;