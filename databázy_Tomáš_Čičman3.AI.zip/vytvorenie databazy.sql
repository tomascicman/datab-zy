
CREATE DATABASE premier_league;
USE premier_league;


CREATE TABLE Coach (
  id INT AUTO_INCREMENT,
PRIMARY KEY(id),
  meno VARCHAR(50),
  vek INT(11),
  narodnost VARCHAR(50),
  tím INT
);

CREATE TABLE captain (
  id INT AUTO_INCREMENT,
PRIMARY KEY(id),
  meno VARCHAR(50),
  vek INT(11),
  narodnost VARCHAR(50),
  pozicia VARCHAR (50),
  tím INT

);

CREATE TABLE Teams (
  id INT AUTO_INCREMENT,
PRIMARY KEY(id),
  nazov VARCHAR(50),
  skratka VARCHAR(50),
  pocet_zapasov INT (11),
  coach_id INT,
  captain_id INT, 
  KEY (captain_id),
  KEY (coach_id),
  FOREIGN KEY (captain_id) REFERENCES captain (id),
  FOREIGN KEY (coach_id) REFERENCES coach (id)
  );

CREATE TABLE Referee (
  id INT AUTO_INCREMENT,
PRIMARY KEY(id),
  meno VARCHAR(50),
  zapasy INT(11),
  pocet_zltych_kariet INT(11),
  pocet_cervenych_kariet INT(11)
);


CREATE TABLE Stadium (
   id INT AUTO_INCREMENT,
PRIMARY KEY(id),
  teams_id INT(11),
  nazov VARCHAR(50),
  referee_id INT(11),
  KEY (teams_id),
  KEY (referee_id),
  FOREIGN KEY (teams_id) REFERENCES Teams (id),
  FOREIGN KEY (referee_id) REFERENCES Referee (id)
);






