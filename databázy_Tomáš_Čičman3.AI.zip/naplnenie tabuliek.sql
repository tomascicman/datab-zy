INSERT INTO Coach
(
   meno,
   vek,
   narodnost,
   tím
)

VALUES ('Ralf Ragnick', '63', 'Nemecko', '13'),
('Antonio Conte', '52', 'Taliansko', '17'),
('Pep Guardiola', '50', 'Španielsko', '12'),
('Jurgen Klopp', '54', 'Nemecko', '11'),
('Steven Gerrard', '41', 'Anglicko', '2'),
('Thomas Tuchel', '48', 'Nemecko', '6'),
('David Moyes', '58', 'Škotsko', '19'),
('Mikel Arteta', '39', 'Španielsko', '1'),
('Bruno Lage', '45', 'Portugalsko', '20'),
('Eddie Howe', '44', 'Anglicko', '14'),
('Graham Potter', '46', 'Anglicko', '4'),
('Brendan Rodgers', '48', 'Anglicko', '10'),
('Dean Smith', '50', 'Anglicko', '15'),
('Thomas Frank', '48', 'Dánsko', '3'),
('Rafael Benitez', '61', 'Španielsko', '8'),
('Ralph Hasenhutll', '54', 'Rakúsko', '16'),
('Marcelo Bielsa', '66', 'Argentína', '9'),
('Patrick Vieira', '45', 'Francúzko', '7'),
('Claudio Ranieri', '70', 'Taliansko', '18'),
('Sean Dyche', '50', 'Anglicko', '5');

INSERT INTO captain
( 
   meno,
   vek,
   narodnost,
   pozicia,
   tím
)

VALUES ('Wes Morgan', '37', 'Anglicko', 'obranca', '10'),
('Pontus Jansson', '30', 'Švédsko', 'obranca','3'),
('Harry Maguire', '28', 'Anglicko', 'obranca','13'),
('César Azpilicueta', '32', 'Španielsko', 'obranca','6'),
('Hugo Lloris', '34', 'Anglicko', 'brankár','17'),
('Luka Milivojevič', '30', 'Srbsko', 'záloha','7'),
('Liam Cooper', '30', 'Anglicko', 'obranca','9'),
('Tyrone Mings', '28', 'Anglicko', 'obranca','2'),
('Séamus Coleman', '33', 'Irsko', 'obranca','8'),
('Conor Coady', '28', 'Anglicko', 'obranca','20'),
('Jordan Henderson', '31', 'Anglicko', 'záloha','11'),
('Jamal Laccelles', '28', 'Anglicko', 'obranca','14'),
('Lewis Dunk', '30', 'Anglicko', 'obranca','4'),
('Fernandinho', '36', 'Brazília', 'záloha','12'),
('Ben Mee', '32', 'Anglicko', 'obranca','5'),
('James Ward-Prowse', '27', 'Anglicko', 'záloha','16'),
('Billy Sharp', '35', 'Anglicko', 'útočnik','15'),
('Troy Deeney', '29', 'Anglicko', 'záloha','18'),
('Mark Noble', '34', 'Anglicko', 'záloha','19'),
('Pierre E. Aubameyang', '32', 'Francúzko', 'útočnik','1');



INSERT INTO Teams
( 
   nazov,
   skratka,
   pocet_zapasov,
   coach_id,
   captain_id 
  )
  
  VALUES ('Arsenal', 'ARS', '14', '8', '20'),    
('Aston Villa', 'AVL', '15', '5', '8'),         
('Brentford', 'BRE', '15', '14', '2'),             
('Bringhton and Hove Albion', 'BHA', '15','11', '13'),  
('Burnley', 'BUR', '14', '20', '15'),     
('Chealse', 'CHE', '15', '6', '4'),           
('Crystal Palace', 'CRY', '15', '18', '6'),        
('Everton', 'EVE', '15', '15', '9'),     
('Leeds United', 'LUFC', '15', '17', '7'),    
('Leicester City', 'LEI', '15', '12', '1'),     
('Liverpool', 'LIV', '15', '4', '11'),          
('Manchester City', 'MCI', '15', '3', '14'),      
('Manchester United', 'MU', '14', '1', '3'),   
('Newcastle United', 'NEW', '15', '10', '12'),      
('Norwich City', 'NOR', '15', '13', '17'),          
('Southampton', 'SOU', '15', '16', '16'),          
('Tottenham Hotspur', 'TOT', '14', '2', '8'),   
('Watford', 'WAT', '15', '19', '18'),             
('West Ham United', 'WHU', '15', '7', '19'),      
('Wolverhampton Wanderers', 'WOL', '15', '9', '1');   


INSERT INTO Referee
( 
   meno,
   zapasy,
   pocet_zltych_kariet,
   pocet_cervenych_kariet 
  )

VALUES ('Michael Oliver', '12', '36', '1'),
('Anthony Taylor', '12', '51', '2'),
('Paul Tierney', '11', '44', '0'),
('Martin Atkinson', '10', '24', '2'),
('Craig Pawson', '10', '36',  '1'),
('Stuart Attwel', '9', '29', '0'),
('Mike Dean', '9', '27', '0'),
('Andre Marriner', '40', '15', '2'),
('Jonathan Moss', '9', '16', '2'),
('David Coote', '8', '47', '2'),
('Chris Kavanagh', '7', '28', '2'),
('Andy Madley', '7', '12', '2'),
('Peter Bankes', '6', '29', '0'),
('Darren England', '5', '29', '1'),
('Kevin Friend', '5', '31', '1'),
('Simon Hooper', '5', '17', '0'),
('Robert Jones', '5', '18', '0'),
('Graham Scott', '3', '19', '0'),
('John Brooks', '1', '5', '0'),
('Michael Salisbury', '1', '6', '0');



INSERT INTO Stadium
( 
   teams_id,
   nazov,
   referee_id
  )
  
  
VALUES ('1', 'Emirates Stadium', '15'),
('2', 'Vila Park', '2'),
('3', 'Brentford Community', '18'),
('4', 'Amex Stadium', '4'),
('5', 'Turf Moor', '7'),
('6', 'Stamford Bridge', '6'),
('7', 'Selhurst Park', '5'),
('8', 'Goodison Park', '11'),
('9', 'Elland Road', '9'),
('10', 'King Power Stadium', '12'),
('11', 'Anfield', '8'),
('12', 'Etihad Stadium', '13'),
('13', 'Old Trafford', '10'),
('14', 'St. James´s Park', '14'),
('15', 'Carrow Road', '1'),
('16', 'St. Mar´s Stadium', '16'),
('17', 'Tottenham Hotspur Stadium', '17'),
('18', 'Vicarage Road', '20'),
('19', 'London Stadium', '3'),
('20', 'Molineux Stadium', '19');










