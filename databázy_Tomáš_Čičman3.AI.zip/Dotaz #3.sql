/*11. SELECT vypise všetko o trenéroch z Anglicka a zoradí podľa názvu tímu*/
SELECT * FROM teams
JOIN coach ON tím = coach_id WHERE narodnost = 'Anglicko' GROUP BY nazov;

/*12. SELECT vypíše meno, vek kapitána a skratku tímu v ktorom hrá ak tím ma odohratých 14 zápasov a zoradí podľa skratky*/
SELECT meno, skratka, vek FROM captain
JOIN teams ON tím = captain_id WHERE pocet_zapasov = 14 GROUP BY skratka;

/*13. SELECT vypíše názov štadiona a id rozhodcu a id tímu podľa toho ak je počet žltých kariet menej ako 23 a zoradí podľa názvu štadiona*/
SELECT nazov, teams_id, referee_id FROM stadium
JOIN referee ON pocet_zltych_kariet = referee_id WHERE pocet_zltych_kariet<23 GROUP BY nazov;

/*14. SELECT vypíše informácie o trenérovi a skratku tímu a zoradí podľa mena trenéra*/
SELECT skratka, meno, vek, narodnost FROM coach
JOIN teams ON tím = coach_id WHERE pocet_zapasov = 15 GROUP BY meno;