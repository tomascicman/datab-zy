<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Prihlasenie</title>
    </head>
    <body>
         <?php

            if ($_POST["meno"] == "tomas" && $_POST["heslo"] == "heslo")
            {
            echo "Si prihlásený";

            }
            else{
            echo "Nie si prihlásený";

            }
     
        ?>
        <input type="button" value="Home" class="homebutton" id="btnHome" 
        onClick="document.location.href='prihlasenie.php'" />
    </body>
</html>